
package car;

public class test {
    
    
    
    
    public static void main(String args[])
    
    {
    String status = "yes";
        
          if( status == "yes")
          {
              System.out.println("A");
          }
    else
          {
              System.out.println("B");
          }
            
        
        
    }
  

}
    
    

